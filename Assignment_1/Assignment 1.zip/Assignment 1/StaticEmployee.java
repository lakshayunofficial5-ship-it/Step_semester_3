public class StaticEmployee {
    String empName;
    double salary;
    static String companyName = "Bright Horizon Technologies";
    static int employeeCount = 0;

    public StaticEmployee(String empName, double salary) {
        this.empName = empName;
        this.salary = salary;
        employeeCount++;
    }

    static void printCompanyInfo() {
        System.out.println(companyName);
        System.out.println("Employees on record: " + employeeCount);
    }

    public static void main(String[] args) {
        StaticEmployee e1 = new StaticEmployee("A", 10000);
        StaticEmployee e2 = new StaticEmployee("B", 20000);
        StaticEmployee e3 = new StaticEmployee("C", 30000);

        StaticEmployee.printCompanyInfo();
    }
}
