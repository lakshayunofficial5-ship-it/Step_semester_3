class FeeAccount {
    protected String accNo;

    public FeeAccount(String accNo) {
        this.accNo = accNo;
    }
}

class HostelFeeAccount extends FeeAccount {
    public HostelFeeAccount(String accNo) {
        super(accNo);
    }
}

public class PaymentProcessor {
    private int hostelCount = 0;
    private int dayScholarCount = 0;

    void processPayment(FeeAccount account, double amount) {
        if (account instanceof HostelFeeAccount) {
            System.out.println("Paid in two installments (hostel account)");
            hostelCount++;
        } else {
            System.out.println("Paid in one go (day-scholar account)");
            dayScholarCount++;
        }
    }

    void printCounts() {
        System.out.println("Hostel accounts processed: " + hostelCount
                + " | Day-scholar accounts processed: " + dayScholarCount);
    }

    public static void main(String[] args) {
        FeeAccount[] accounts = {
            new HostelFeeAccount("H1"),
            new HostelFeeAccount("H2"),
            new FeeAccount("F1"),
            new FeeAccount("F2")
        };

        PaymentProcessor processor = new PaymentProcessor();
        for (FeeAccount acc : accounts) {
            processor.processPayment(acc, 60000);
        }
        processor.printCounts();
    }
}
